package com.moss.project.eneasy.business;

import com.moss.project.eneasy.model.UserEntity;

public interface IBaseService {
	public  UserEntity getCurrentUser(); 
}
